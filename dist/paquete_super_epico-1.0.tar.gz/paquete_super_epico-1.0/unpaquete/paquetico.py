def multiplicar(o1,o2):
    print("mult= "+str(o1*o2))